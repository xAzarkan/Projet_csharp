﻿using System.Windows.Forms;
using System.Data;

namespace CO2_Interface.SerialDataHandler
{
    internal static class Treatment
    {
        
    }
}
